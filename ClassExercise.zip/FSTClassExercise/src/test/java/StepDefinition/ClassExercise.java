package StepDefinition;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ClassExercise {

	
	WebDriver driver;
	@Given("user launches required website")
	public void user_launches_required_website() {

		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\PoojaHipparagi\\Desktop\\Auto_Cucu\\chromedriver_win32\\chromedriver.exe");
		    driver = new ChromeDriver();
		    driver.get("http://elearningm1.upskills.in/index.php");
		    driver.manage().window().maximize();
		    driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/ul/li[1]/a")).click(); //Signup
		    
	}

	@Given("signup using required details")
	public void signup_using_required_details(io.cucumber.datatable.DataTable dataTable) {
		List<String> data=dataTable.asList();
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[1]/div[1]/input")).sendKeys(data.get(1)); //Firstname
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[2]/div[1]/input")).sendKeys(data.get(3)); //Lastname
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[3]/div[1]/input")).sendKeys(data.get(5)); //Email
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[5]/div[1]/input")).sendKeys(data.get(7)); //Username
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[6]/div[1]/input")).sendKeys(data.get(9)); //Password
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[8]/div[1]/input")).sendKeys(data.get(11)); //Confirm Password
	}

	@Given("sumbit the registration form")
	public void sumbit_the_registration_form() {
	    
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/div[16]/div[1]/button")).click();
	}

	@When("successfully registered Verify the message and click next")
	public void successfully_registered_Verify_the_message_and_click_next() {
	   
		if(driver.getPageSource().contains("Your personal settings have registered.")) {
			System.out.println("Required Text Presents");
			driver.findElement(By.xpath("/html/body/div[1]/div/div/div/form/fieldset/button")).click();}
		else
			System.out.println("element not present");

	    
	}

	@When("user selects username from the profile")
	public void user_selects_username_from_the_profile() {

		driver.findElement(By.xpath("/html/body/div[1]/header/section[2]/nav/div/div[2]/ul[2]/li[1]/a")).click(); //Dropdown
		driver.findElement(By.xpath("/html/body/div[1]/header/section[2]/nav/div/div[2]/ul[2]/li[1]/ul/li/a[1]")).click();//Profiel
		System.out.println("Profile choosed form Dropdown");
		
	}

	@When("clicks on Message")
	public void clicks_on_Message() {
	    
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[1]/div[2]/div/div/div[2]/div/ul/li[2]/a")).click();
		
		
	}

	@Then("user clicks on compose message")
	public void user_clicks_on_compose_message() {
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/div[1]/div/div[1]/a[1]/img")).click();}

	
	
	@Then("user enters required details and clicks on send message{int}")
	public void user_enters_required_details_and_clicks_on_send_message(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/div/div[2]/form/fieldset/div[1]/div[1]/span/span[1]/span/ul/li/input")).sendKeys("Sample");
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/div/div[2]/form/fieldset/div[2]/div[1]/input")).sendKeys("Email check");
		driver.findElement(By.xpath("/html")).sendKeys("hi hello");
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/div/div[2]/form/fieldset/div[6]/div[1]/button")).click();
		
		
		    
		}

	}


